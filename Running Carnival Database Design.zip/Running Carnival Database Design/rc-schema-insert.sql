-- INSERTING into CARNIVAL

INSERT INTO carnival (
    carn_date,
    carn_name,
    carn_director,
    carn_location
) VALUES (
    TO_DATE('24/SEP/2024', 'DD/MON/YYYY'),
    'RM Spring Series Clayton 2024',
    'Mary Lim',
    'Scenic Blvd, Clayton, VIC, 3800'
);

INSERT INTO carnival (
    carn_date,
    carn_name,
    carn_director,
    carn_location
) VALUES (
    TO_DATE('01/OCT/2024', 'DD/MON/YYYY'),
    'RM Spring Series Caulfield 2024',
    'Catherine Stoupas',
    '900 Dandenong Rd, Caulfield, VIC, 3145'
);

INSERT INTO carnival (
    carn_date,
    carn_name,
    carn_director,
    carn_location
) VALUES (
    TO_DATE('05/FEB/2024', 'DD/MON/YYYY'),
    'RM Summer Series Caulfield 2024',
    'Steve Johnson',
    '900 Dandenong Rd, Caulfield, VIC, 3145'
);

INSERT INTO carnival (
    carn_date,
    carn_name,
    carn_director,
    carn_location
) VALUES (
    TO_DATE('14/MAR/2024', 'DD/MON/YYYY'),
    'RM Autumn Series Clayton 2024',
    'Mary Lim',
    'Scenic Blvd, Clayton, VIC, 3800'
);

INSERT INTO carnival (
    carn_date,
    carn_name,
    carn_director,
    carn_location
) VALUES (
    TO_DATE('29/May/2024', 'DD/MON/YYYY'),
    'RM Autumn Series Caulfield 2024',
    'Steve Johnson',
    '900 Dandenong Rd, Caulfield, VIC, 3145'
);

-- INSERTING into CHARITY
INSERT INTO charity (
    char_id,
    char_name,
    char_contact,
    char_phone
) VALUES (
    1,
    'RSPCA',
    'Ms. Susan Madden',
    '6140020002'
);

INSERT INTO charity (
    char_id,
    char_name,
    char_contact,
    char_phone
) VALUES (
    2,
    'Beyond Blue',
    'Ms. Julia Gillard',
    '6140040004'
);

INSERT INTO charity (
    char_id,
    char_name,
    char_contact,
    char_phone
) VALUES (
    3,
    'Salvation Army',
    'Mr. Michael Jackson',
    '6140080008'
);

INSERT INTO charity (
    char_id,
    char_name,
    char_contact,
    char_phone
) VALUES (
    4,
    'Amnesty International',
    'Ms. Navinda Pal',
    '6140081234'
);

-- INSERTING into EVENTTYPE
INSERT INTO eventtype (
    eventtype_code,
    eventtype_desc
) VALUES (
    '42K',
    '42.2 Km Marathon'
);

INSERT INTO eventtype (
    eventtype_code,
    eventtype_desc
) VALUES (
    '21K',
    '21.1 Km Half Marathon'
);

INSERT INTO eventtype (
    eventtype_code,
    eventtype_desc
) VALUES (
    '10K',
    '10 Km Run'
);

INSERT INTO eventtype (
    eventtype_code,
    eventtype_desc
) VALUES (
    '5K ',
    '5 Km Run'
);

INSERT INTO eventtype (
    eventtype_code,
    eventtype_desc
) VALUES (
    '3K ',
    '3 Km Community Run/Walk'
);

-- INSERTING into EVENT
INSERT INTO event (
    event_id,
    carn_date,
    eventtype_code,
    event_starttime
) VALUES (
    1,
    TO_DATE('24/SEP/2024', 'DD/MON/YYYY'),
    '5K ',
    TO_DATE('09:30', 'HH:MI')
);

INSERT INTO event (
    event_id,
    carn_date,
    eventtype_code,
    event_starttime
) VALUES (
    2,
    TO_DATE('24/SEP/2024', 'DD/MON/YYYY'),
    '10K',
    TO_DATE('08:30', 'HH:MI')
);

INSERT INTO event (
    event_id,
    carn_date,
    eventtype_code,
    event_starttime
) VALUES (
    3,
    TO_DATE('01/OCT/2024', 'DD/MON/YYYY'),
    '5K ',
    TO_DATE('09:00', 'HH:MI')
);

INSERT INTO event (
    event_id,
    carn_date,
    eventtype_code,
    event_starttime
) VALUES (
    4,
    TO_DATE('01/OCT/2024', 'DD/MON/YYYY'),
    '10K',
    TO_DATE('08:30', 'HH:MI')
);

INSERT INTO event (
    event_id,
    carn_date,
    eventtype_code,
    event_starttime
) VALUES (
    5,
    TO_DATE('01/OCT/2024', 'DD/MON/YYYY'),
    '21K',
    TO_DATE('08:00', 'HH:MI')
);

INSERT INTO event (
    event_id,
    carn_date,
    eventtype_code,
    event_starttime
) VALUES (
    6,
    TO_DATE('05/FEB/2024', 'DD/MON/YYYY'),
    '3K ',
    TO_DATE('08:30', 'HH:MI')
);

INSERT INTO event (
    event_id,
    carn_date,
    eventtype_code,
    event_starttime
) VALUES (
    7,
    TO_DATE('05/FEB/2024', 'DD/MON/YYYY'),
    '5K ',
    TO_DATE('08:30', 'HH:MI')
);

INSERT INTO event (
    event_id,
    carn_date,
    eventtype_code,
    event_starttime
) VALUES (
    8,
    TO_DATE('05/FEB/2024', 'DD/MON/YYYY'),
    '10K',
    TO_DATE('08:00', 'HH:MI')
);

INSERT INTO event (
    event_id,
    carn_date,
    eventtype_code,
    event_starttime
) VALUES (
    9,
    TO_DATE('05/FEB/2024', 'DD/MON/YYYY'),
    '21K',
    TO_DATE('08:00', 'HH:MI')
);

INSERT INTO event (
    event_id,
    carn_date,
    eventtype_code,
    event_starttime
) VALUES (
    10,
    TO_DATE('14/MAR/2024', 'DD/MON/YYYY'),
    '3K ',
    TO_DATE('08:00', 'HH:MI')
);

INSERT INTO event (
    event_id,
    carn_date,
    eventtype_code,
    event_starttime
) VALUES (
    11,
    TO_DATE('14/MAR/2024', 'DD/MON/YYYY'),
    '42K',
    TO_DATE('07:45', 'HH:MI')
);

INSERT INTO event (
    event_id,
    carn_date,
    eventtype_code,
    event_starttime
) VALUES (
    12,
    TO_DATE('29/May/2024', 'DD/MON/YYYY'),
    '5K ',
    TO_DATE('08:45', 'HH:MI')
);

INSERT INTO event (
    event_id,
    carn_date,
    eventtype_code,
    event_starttime
) VALUES (
    13,
    TO_DATE('29/May/2024', 'DD/MON/YYYY'),
    '10K',
    TO_DATE('08:30', 'HH:MI')
);

INSERT INTO event (
    event_id,
    carn_date,
    eventtype_code,
    event_starttime
) VALUES (
    14,
    TO_DATE('29/May/2024', 'DD/MON/YYYY'),
    '21K',
    TO_DATE('08:00', 'HH:MI')
);


-- INSERTING into EMERCONTACT

INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '0433377788',
    'Dave',
    'Freeman'
);

INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '0433555666',
    'Sonya',
    'De Costella'
);

INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '0433666777',
    NULL,
    'Smith'
);

INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '0435123567',
    'Elizabeth',
    'Dunn'
);

INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '0411222345',
    'Bob',
    'Ryan'
);

INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '0450789690',
    'Nithin',
    'Pal'
);

INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '0421909808',
    'Ling',
    'Shu'
);

INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '0312345678',
    'Fernando',
    'Rose'
);

INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '0387654321',
    'Adrianna',
    'Rose'
);

INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '0387634121',
    'Dave',
    'Radcliffe'
);

-- INSERTING into COMPETITOR

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    1,
    'Cathy',
    'Freeman',
    'F',
    TO_DATE('02/JAN/1975', 'DD/MON/YYYY'),
    'cathy@gmail.com',
    'N',
    '0422666777',
    'T',
    '0433377788'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    2,
    'Rob',
    'De Costella',
    'M',
    TO_DATE('15/MAR/1950', 'DD/MON/YYYY'),
    'rob@gmail.com',
    'N',
    '0422888999',
    'T',
    '0433555666'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    3,
    'Brigid',
    'Radcliffe',
    'F',
    TO_DATE('10/OCT/1997', 'DD/MON/YYYY'),
    'brigid@byb.org',
    'N',
    '0432412342',
    'T',
    '0387634121'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    4,
    'Bob',
    'Ryan',
    'M',
    TO_DATE('02/NOV/1955', 'DD/MON/YYYY'),
    'bob@monash.edu',
    'Y',
    '0411222345',
    'T',
    '0435123567'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    5,
    'Sam',
    'Ryan',
    'M',
    TO_DATE('15/APR/2001', 'DD/MON/YYYY'),
    'sam@student.monash.edu',
    'Y',
    '0353242132',
    'G',
    '0411222345'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    6,
    'Jane',
    'Ryan',
    'F',
    TO_DATE('01/JAN/2003', 'DD/MON/YYYY'),
    'jane@student.monash.edu',
    'Y',
    '0353242132',
    'G',
    '0411222345'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    7,
    'Dan',
    'Chu',
    'M',
    TO_DATE('06/JUN/1955', 'DD/MON/YYYY'),
    'dan@student.monash.edu',
    'Y',
    '0403999808',
    'F',
    '0450789690'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    8,
    'Srini',
    'Vash',
    'M',
    TO_DATE('31/AUG/1998', 'DD/MON/YYYY'),
    'srini@student.monash.edu',
    'Y',
    '0411234567',
    'F',
    '0450789690'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    9,
    'Nithin',
    'Pal',
    'M',
    TO_DATE('30/OCT/1998', 'DD/MON/YYYY'),
    'nithin@student.monash.edu',
    'Y',
    '0450789690',
    'F',
    '0421909808'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    10,
    'Ling',
    'Shu',
    'F',
    TO_DATE('23/JUL/1980', 'DD/MON/YYYY'),
    'shuling@gmail.com',
    'Y',
    '0421909808',
    'F',
    '0433666777'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    11,
    'Nan',
    'Shu',
    'F',
    TO_DATE('13/FEB/2010', 'DD/MON/YYYY'),
    'nanshu@gmail.com',
    'N',
    '0421909808',
    'P',
    '0421909808'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    12,
    'Fan',
    'Shu',
    'M',
    TO_DATE('31/AUG/2005', 'DD/MON/YYYY'),
    'shufan@gmail.com',
    'N',
    '0421909808',
    'P',
    '0421909808'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    13,
    'William',
    NULL,
    'M',
    TO_DATE('23/OCT/2008', 'DD/MON/YYYY'),
    'will@gmail.com',
    'N',
    '0421909808',
    'G',
    '0421909808'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    14,
    'Pamela',
    'Sim',
    'F',
    TO_DATE('12/DEC/1990', 'DD/MON/YYYY'),
    'pamela@monash.edu',
    'Y',
    '0430450678',
    'F',
    '0435123567'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    15,
    'Sebastian',
    'Coe',
    'M',
    TO_DATE('11/NOV/1960', 'DD/MON/YYYY'),
    's.coe@monash.edu',
    'Y',
    '0421990880',
    'F',
    '0433377788'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    16,
    'Fernando',
    'Rose',
    'M',
    TO_DATE('10/OCT/1970', 'DD/MON/YYYY'),
    'f.rose@redc.org',
    'N',
    '0312345678',
    'T',
    '0387654321'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    17,
    'Adrianna',
    'Rose',
    'F',
    TO_DATE('11/NOV/1971', 'DD/MON/YYYY'),
    'a.rose@redc.org',
    'N',
    '0387654321',
    'T',
    '0312345678'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    18,
    'Annamaria',
    'Rose',
    'F',
    TO_DATE('12/DEC/2004', 'DD/MON/YYYY'),
    'a.rose@redc.org',
    'N',
    '0312345678',
    'P',
    '0312345678'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    19,
    'Juan',
    'Rose',
    'M',
    TO_DATE('23/OCT/2000', 'DD/MON/YYYY'),
    'juan@redc.org',
    'Y',
    '0421909808',
    'F',
    '0450789690'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    20,
    NULL,
    'Nguyen',
    'F',
    TO_DATE('02/OCT/1998', 'DD/MON/YYYY'),
    'nguyen@gmail.com',
    'Y',
    '0433123456',
    'F',
    '0433666777'
);

-- INSERTING into ENTRY

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    1,
    1,
    TO_DATE('09:31:02 AM', 'hh:mi:ss am'),
    TO_DATE('10:03:32 AM', 'hh:mi:ss am'),
    5,
    1
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    1,
    2,
    TO_DATE('09:31:04 AM', 'hh:mi:ss am'),
    TO_DATE('10:02:22 AM', 'hh:mi:ss am'),
    6,
    1
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    2,
    1,
    TO_DATE('08:30:57 AM', 'hh:mi:ss am'),
    TO_DATE('09:38:08 AM', 'hh:mi:ss am'),
    1,
    2
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    2,
    2,
    TO_DATE('08:32:05 AM', 'hh:mi:ss am'),
    TO_DATE('09:27:06 AM', 'hh:mi:ss am'),
    2,
    1
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    2,
    3,
    TO_DATE('08:32:06 AM', 'hh:mi:ss am'),
    TO_DATE('09:38:45 AM', 'hh:mi:ss am'),
    3,
    1
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    2,
    4,
    TO_DATE('08:31:53 AM', 'hh:mi:ss am'),
    TO_DATE('09:29:11 AM', 'hh:mi:ss am'),
    7,
    NULL
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    3,
    1,
    TO_DATE('09:00:19 AM', 'hh:mi:ss am'),
    TO_DATE('09:35:17 AM', 'hh:mi:ss am'),
    17,
    3
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    3,
    2,
    TO_DATE('09:00:15 AM', 'hh:mi:ss am'),
    TO_DATE('09:35:16 AM', 'hh:mi:ss am'),
    18,
    3
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    3,
    3,
    TO_DATE('09:00:17 AM', 'hh:mi:ss am'),
    TO_DATE('09:35:20 AM', 'hh:mi:ss am'),
    19,
    3
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    3,
    4,
    TO_DATE('09:01:12 AM', 'hh:mi:ss am'),
    TO_DATE('09:29:17 AM', 'hh:mi:ss am'),
    20,
    1
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    3,
    5,
    TO_DATE('09:01:21 AM', 'hh:mi:ss am'),
    TO_DATE('09:41:29 AM', 'hh:mi:ss am'),
    14,
    2
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    4,
    1,
    TO_DATE('08:31:01 AM', 'hh:mi:ss am'),
    TO_DATE('09:28:04 AM', 'hh:mi:ss am'),
    4,
    4
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    4,
    2,
    TO_DATE('08:31:02 AM', 'hh:mi:ss am'),
    TO_DATE('09:29:09 AM', 'hh:mi:ss am'),
    7,
    1
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    8,
    1,
    TO_DATE('08:00:56 AM', 'hh:mi:ss am'),
    TO_DATE('09:05:55 AM', 'hh:mi:ss am'),
    9,
    3
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    8,
    2,
    TO_DATE('08:01:02 AM', 'hh:mi:ss am'),
    TO_DATE('09:06:51 AM', 'hh:mi:ss am'),
    7,
    3
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    8,
    3,
    TO_DATE('08:00:56 AM', 'hh:mi:ss am'),
    TO_DATE('09:05:56 AM', 'hh:mi:ss am'),
    8,
    2
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    8,
    4,
    TO_DATE('08:01:02 AM', 'hh:mi:ss am'),
    TO_DATE('09:06:01 AM', 'hh:mi:ss am'),
    6,
    3
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    9,
    1,
    NULL,
    NULL,
    14,
    4
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    9,
    2,
    TO_DATE('08:05:22 AM', 'hh:mi:ss am'),
    TO_DATE('10:48:32 AM', 'hh:mi:ss am'),
    16,
    2
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    9,
    3,
    TO_DATE('08:05:22 AM', 'hh:mi:ss am'),
    TO_DATE('10:48:32 AM', 'hh:mi:ss am'),
    17,
    2
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    10,
    1,
    TO_DATE('08:00:23 AM', 'hh:mi:ss am'),
    TO_DATE('08:13:05 AM', 'hh:mi:ss am'),
    10,
    NULL
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    10,
    2,
    TO_DATE('08:00:23 AM', 'hh:mi:ss am'),
    TO_DATE('08:12:54 AM', 'hh:mi:ss am'),
    11,
    NULL
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    10,
    3,
    TO_DATE('08:00:24 AM', 'hh:mi:ss am'),
    TO_DATE('08:15:29 AM', 'hh:mi:ss am'),
    12,
    NULL
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    10,
    4,
    TO_DATE('08:00:23 AM', 'hh:mi:ss am'),
    TO_DATE('08:13:45 AM', 'hh:mi:ss am'),
    13,
    NULL
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    10,
    5,
    TO_DATE('08:00:24 AM', 'hh:mi:ss am'),
    TO_DATE('08:12:55 AM', 'hh:mi:ss am'),
    19,
    NULL
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    11,
    1,
    TO_DATE('07:45:01 AM', 'hh:mi:ss am'),
    TO_DATE('11:42:17 AM', 'hh:mi:ss am'),
    14,
    3
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    11,
    2,
    TO_DATE('07:45:01 AM', 'hh:mi:ss am'),
    TO_DATE('12:05:11 PM', 'hh:mi:ss am'),
    15,
    3
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    11,
    3,
    TO_DATE('07:45:01 AM', 'hh:mi:ss am'),
    TO_DATE('10:50:36 AM', 'hh:mi:ss am'),
    16,
    2
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    12,
    1,
    NULL,
    NULL,
    20,
    4
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    12,
    2,
    NULL,
    NULL,
    15,
    1
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    13,
    1,
    NULL,
    NULL,
    8,
    2
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    13,
    2,
    NULL,
    NULL,
    7,
    3
);

-- INSERTING into TEAM

INSERT INTO team (
    team_id,
    team_name,
    carn_date,
    team_no_members,
    event_id,
    entry_no,
    char_id
) VALUES (
    1,
    'Gentle Earth',
    TO_DATE('24/SEP/2024', 'DD/MON/YYYY'),
    3,
    2,
    2,
    1
);

INSERT INTO team (
    team_id,
    team_name,
    carn_date,
    team_no_members,
    event_id,
    entry_no,
    char_id
) VALUES (
    2,
    'Avengers',
    TO_DATE('01/OCT/2024', 'DD/MON/YYYY'),
    3,
    3,
    1,
    3
);

INSERT INTO team (
    team_id,
    team_name,
    carn_date,
    team_no_members,
    event_id,
    entry_no,
    char_id
) VALUES (
    3,
    'Gentle Earth',
    TO_DATE('01/OCT/2024', 'DD/MON/YYYY'),
    2,
    4,
    2,
    1
);

INSERT INTO team (
    team_id,
    team_name,
    carn_date,
    team_no_members,
    event_id,
    entry_no,
    char_id
) VALUES (
    4,
    'Footloose',
    TO_DATE('05/FEB/2024', 'DD/MON/YYYY'),
    4,
    8,
    1,
    3
);

INSERT INTO team (
    team_id,
    team_name,
    carn_date,
    team_no_members,
    event_id,
    entry_no,
    char_id
) VALUES (
    5,
    'Champion Stars',
    TO_DATE('05/FEB/2024', 'DD/MON/YYYY'),
    2,
    9,
    3,
    2
);

INSERT INTO team (
    team_id,
    team_name,
    carn_date,
    team_no_members,
    event_id,
    entry_no,
    char_id
) VALUES (
    6,
    'Happy Feet',
    TO_DATE('14/MAR/2024', 'DD/MON/YYYY'),
    5,
    10,
    1,
    1
);

INSERT INTO team (
    team_id,
    team_name,
    carn_date,
    team_no_members,
    event_id,
    entry_no,
    char_id
) VALUES (
    7,
    'Kind World',
    TO_DATE('29/MAY/2024', 'DD/MON/YYYY'),
    2,
    13,
    2,
    NULL
);

UPDATE entry
SET
    team_id = 1
WHERE
    ( event_id = 2
      AND entry_no = 1 )
    OR ( event_id = 2
         AND entry_no = 2 )
    OR ( event_id = 2
         AND entry_no = 3 );

UPDATE entry
SET
    team_id = 1
WHERE
    ( event_id = 2
      AND entry_no = 1 )
    OR ( event_id = 2
         AND entry_no = 2 )
    OR ( event_id = 2
         AND entry_no = 3 );

UPDATE entry
SET
    team_id = 2
WHERE
    ( event_id = 3
      AND entry_no = 1 )
    OR ( event_id = 3
         AND entry_no = 2 )
    OR ( event_id = 3
         AND entry_no = 3 );

UPDATE entry
SET
    team_id = 3
WHERE
    ( event_id = 4
      AND entry_no = 1 )
    OR ( event_id = 4
         AND entry_no = 2 );

UPDATE entry
SET
    team_id = 4
WHERE
    ( event_id = 8
      AND entry_no = 1 )
    OR ( event_id = 8
         AND entry_no = 2 )
    OR ( event_id = 8
         AND entry_no = 3 )
    OR ( event_id = 8
         AND entry_no = 4 );

UPDATE entry
SET
    team_id = 5
WHERE
    ( event_id = 9
      AND entry_no = 2 )
    OR ( event_id = 9
         AND entry_no = 3 );

UPDATE entry
SET
    team_id = 6
WHERE
    ( event_id = 10
      AND entry_no = 1 )
    OR ( event_id = 10
         AND entry_no = 2 )
    OR ( event_id = 10
         AND entry_no = 3 )
    OR ( event_id = 10
         AND entry_no = 4 )
    OR ( event_id = 10
         AND entry_no = 5 );

UPDATE entry
SET
    team_id = 7
WHERE
    ( event_id = 13
      AND entry_no = 1 )
    OR ( event_id = 13
         AND entry_no = 2 );


COMMIT;
