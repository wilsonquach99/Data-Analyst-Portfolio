--4(a)
ALTER TABLE entry ADD (
    entry_elapsedtime NUMBER(5, 2)
);

COMMENT ON COLUMN entry.entry_elapsedtime IS
    'Elapsed time for this run';

UPDATE entry
SET
    entry_elapsedtime = ( entry_finishtime - entry_starttime ) * 24 * 60;
    
COMMIT;

--4(b)
DROP TABLE team_charity;

CREATE TABLE team_charity
    AS
        SELECT
            team_id,
            char_id,
            100 AS teamchar_percentage
        FROM
            team
        WHERE
            char_id IS NOT NULL;

COMMENT ON COLUMN team_charity.team_id IS
    'Team identifier (unique)';

COMMENT ON COLUMN team_charity.char_id IS
    'Charity unique identifier';

COMMENT ON COLUMN team_charity.teamchar_percentage IS
    'Percentage of funds that goes to the charity';

ALTER TABLE team_charity MODIFY (char_id NOT NULL);

ALTER TABLE team_charity MODIFY (teamchar_percentage NOT NULL);

ALTER TABLE team_charity
ADD CONSTRAINT teamcharpercent_check CHECK (teamchar_percentage BETWEEN 0 AND 100);

ALTER TABLE team_charity ADD CONSTRAINT teamcharity_pk PRIMARY KEY (team_id, char_id);

ALTER TABLE team_charity
ADD CONSTRAINT team_teamcharity_fk FOREIGN KEY (team_id)
REFERENCES team (team_id);

ALTER TABLE team_charity
ADD CONSTRAINT charity_teamcharity_fk FOREIGN KEY (char_id)
REFERENCES charity (char_id);

ALTER TABLE team DROP COLUMN char_id;

--4(c)

DROP TABLE official;

DROP TABLE official_role;

CREATE TABLE official_role (
    or_id   NUMBER(2) NOT NULL,
    or_desc VARCHAR(50) NOT NULL
);

COMMENT ON COLUMN official_role.or_id IS
    'Official role identifier (unique)';

COMMENT ON COLUMN official_role.or_desc IS
    'Official role description';
    
ALTER TABLE official_role ADD CONSTRAINT officialrole_pk PRIMARY KEY ( or_id );

INSERT INTO official_role VALUES (
    1,
    'time keeper'
);

INSERT INTO official_role VALUES (
    2,
    'marshal'
);

INSERT INTO official_role VALUES (
    3,
    'starter'
);

INSERT INTO official_role VALUES (
    4,
    'first aid'
);


CREATE TABLE official (
    comp_no   NUMBER(5) NOT NULL,
    carn_date DATE NOT NULL,
    or_id     NUMBER(2) NOT NULL
);

COMMENT ON COLUMN official.comp_no IS
    'Competitor registration number (unique)';

COMMENT ON COLUMN official.carn_date IS
    'Date of carnival (unique identifier)';

COMMENT ON COLUMN official.or_id IS
    'Official role identifier (unique)';

ALTER TABLE official ADD CONSTRAINT official_pk PRIMARY KEY ( comp_no,
                                                              carn_date );

ALTER TABLE official
    ADD CONSTRAINT competitor_official_fk FOREIGN KEY ( comp_no )
        REFERENCES competitor ( comp_no );

ALTER TABLE official
    ADD CONSTRAINT carnival_official_fk FOREIGN KEY ( carn_date )
        REFERENCES carnival ( carn_date );

ALTER TABLE official
    ADD CONSTRAINT officialrole_official_fk FOREIGN KEY ( or_id )
        REFERENCES official_role ( or_id );


