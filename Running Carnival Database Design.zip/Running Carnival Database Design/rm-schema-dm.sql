--3(a)
DROP SEQUENCE comp_seq;

CREATE SEQUENCE comp_seq START WITH 100 INCREMENT BY 1;

DROP SEQUENCE team_seq;

CREATE SEQUENCE team_seq START WITH 100 INCREMENT BY 1;


--3(b)

INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '0476541234',
    'Jack',
    'Kai'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    comp_seq.nextval,
    'Daniel',
    'Kai',
    'M',
    TO_DATE('16/OCT/2003', 'DD/MON/YYYY'),
    'daniel.kai2003@gmail.com',
    'Y',
    '0437315362',
    'G',
    '0476541234'
);


INSERT INTO entry (
    event_id,
    entry_no,
    comp_no,
    char_id
) VALUES (
    (
        SELECT
            event_id
        FROM
                 event
            NATURAL JOIN carnival
            NATURAL JOIN eventtype
        WHERE
                lower(carn_name) = lower('RM Autumn Series Caulfield 2024')
            AND lower(eventtype_desc) = lower('21.1 Km Half Marathon')
    ),
    (
        SELECT
            nvl(MAX(entry_no),
                0) + 1
        FROM
            entry
        WHERE
            event_id = (
                SELECT
                    event_id
                FROM
                         event
                    NATURAL JOIN carnival
                    NATURAL JOIN eventtype
                WHERE
                        lower(carn_name) = lower('RM Autumn Series Caulfield 2024')
                    AND lower(eventtype_desc) = lower('21.1 Km Half Marathon')
            )
    ),
    comp_seq.CURRVAL,
    (
        SELECT
            char_id
        FROM
            charity
        WHERE
            lower(char_name) = lower('Beyond Blue')
    )
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    comp_seq.nextval,
    'Annabelle',
    'Kai',
    'F',
    TO_DATE('08/Nov/2002', 'DD/MON/YYYY'),
    'annabelle811kai@gmail.com',
    'Y',
    '0437315384',
    'G',
    '0476541234'
);

INSERT INTO entry (
    event_id,
    entry_no,
    comp_no,
    char_id
) VALUES (
    (
        SELECT
            event_id
        FROM
                 event
            NATURAL JOIN carnival
            NATURAL JOIN eventtype
        WHERE
                lower(carn_name) = lower('RM Autumn Series Caulfield 2024')
            AND lower(eventtype_desc) = lower('21.1 Km Half Marathon')
    ),
    (
        SELECT
            nvl(MAX(entry_no),0) + 1
        FROM
            entry
        WHERE
            event_id = (
                SELECT
                    event_id
                FROM
                         event
                    NATURAL JOIN carnival
                    NATURAL JOIN eventtype
                WHERE
                        lower(carn_name) = lower('RM Autumn Series Caulfield 2024')
                    AND lower(eventtype_desc) = lower('21.1 Km Half Marathon')
            )
    ),
    comp_seq.CURRVAL,
    (
        SELECT
            char_id
        FROM
            charity
        WHERE
            lower(char_name) = lower('Amnesty International')
    )
);

COMMIT;

--3(c)

INSERT INTO team (
    team_id,
    team_name,
    carn_date,
    team_no_members,
    event_id,
    entry_no,
    char_id
) VALUES (
    team_seq.NEXTVAL,
    'Kai Speedstars',
    (
        SELECT
            carn_date
        FROM
                 carnival
            NATURAL JOIN event
            NATURAL JOIN eventtype
        WHERE
                lower(carn_name) = lower('RM Autumn Series Caulfield 2024')
            AND lower(eventtype_desc) = lower('21.1 Km Half Marathon')
    ),
    1,
    (
        SELECT
            event_id
        FROM
                 carnival
            NATURAL JOIN event
            NATURAL JOIN eventtype
        WHERE
                lower(carn_name) = lower('RM Autumn Series Caulfield 2024')
            AND lower(eventtype_desc) = lower('21.1 Km Half Marathon')
    ),
    (
        SELECT
            entry_no
        FROM
                 competitor
            NATURAL JOIN entry
            NATURAL JOIN event
            NATURAL JOIN carnival
        WHERE
                lower(comp_fname) = lower('Annabelle')
            AND lower(comp_lname) = lower('Kai')
            AND lower(carn_name) = lower('RM Autumn Series Caulfield 2024')
    ),
    (
        SELECT
            char_id
        FROM
            charity
        WHERE
            lower(char_name) = lower('Beyond Blue')
    )
);

UPDATE entry
SET
    team_id = team_seq.currval
WHERE
        event_id = (
            SELECT
                event_id
            FROM
                     carnival
                NATURAL JOIN event
                NATURAL JOIN eventtype
            WHERE
                    lower(carn_name) = lower('RM Autumn Series Caulfield 2024')
                AND lower(eventtype_desc) = lower('21.1 Km Half Marathon')
        )
    AND entry_no = (
        SELECT
            entry_no
        FROM
                 competitor
            NATURAL JOIN entry
            NATURAL JOIN event
            NATURAL JOIN carnival
        WHERE
                lower(comp_fname) = lower('Annabelle')
            AND lower(comp_lname) = lower('Kai')
            AND lower(carn_name) = lower('RM Autumn Series Caulfield 2024')
    );

COMMIT;
    
--3(d)

UPDATE entry
SET
    event_id = (
        SELECT
            event_id
        FROM
                 event
            NATURAL JOIN carnival
            NATURAL JOIN eventtype
        WHERE
                lower(carn_name) = lower('RM Autumn Series Caulfield 2024')
            AND lower(eventtype_desc) = lower('10 Km Run')
    ),
    entry_no = (
        SELECT
            nvl(MAX(entry_no), 0) + 1
        FROM
            entry
        WHERE
            event_id = (
                SELECT
                    event_id
                FROM
                         event
                    NATURAL JOIN carnival
                    NATURAL JOIN eventtype
                WHERE
                        lower(carn_name) = lower('RM Autumn Series Caulfield 2024')
                    AND lower(eventtype_desc) = lower('10 Km Run')
            )
    ),
    team_id = (
        SELECT
            team_id
        FROM
            team
        WHERE
                lower(team_name) = lower('Kai Speedstars')
            AND carn_date = (
                SELECT
                    carn_date
                FROM
                    carnival
                WHERE
                    lower(carn_name) = lower('RM Autumn Series Caulfield 2024')
            )
    )
WHERE
        event_id = (
            SELECT
                event_id
            FROM
                     event
                NATURAL JOIN carnival
                NATURAL JOIN eventtype
            WHERE
                    lower(carn_name) = lower('RM Autumn Series Caulfield 2024')
                AND lower(eventtype_desc) = lower('21.1 Km Half Marathon')
        )
    AND entry_no = (
        SELECT
            entry_no
        FROM
                 competitor
            NATURAL JOIN entry
            NATURAL JOIN event
            NATURAL JOIN carnival
        WHERE
                upper(carn_name) = upper('RM Autumn Series Caulfield 2024')
            AND lower(comp_fname) = lower('Daniel')
            AND lower(comp_lname) = lower('Kai')
    );

UPDATE team
SET
    team_no_members = team_no_members + 1
WHERE
        lower(team_name) = lower( 'Kai Speedstars' );

    
COMMIT;

--3(e) One week later, �Daniel Kai� indicates that his injury has gotten a lot worse and that
--he will need to withdraw from the �RM Autumn Series Caulfield 2024� carnival.
--�Daniel Kai� also indicates that he is looking forward to competing in the next 2022
--carnival

--On the other hand, �Annabelle Kai� has asked a few friends to join her team for this
--carnival but she is not sure if any have actually taken up the offer, so she directs Run
--Monash that her team, "Kai Speedstars", should be disbanded. She will still
-- in the carnival as an individual runner and she will support the �Beyond
--Blue� charity

--Make these changes to the data in the database. You may assume �Daniel Kai� and
--�Annabelle Kai� are the only competitors of that name in the �RM Autumn Series
--Caulfield 2022� carnival. These changes must be treated as a single transaction.


DELETE FROM entry
WHERE
        event_id = (
            SELECT
                event_id
            FROM
                     competitor
                NATURAL JOIN entry
                NATURAL JOIN event
                NATURAL JOIN carnival
            WHERE
                    upper(carn_name) = upper('RM Autumn Series Caulfield 2024')
                AND upper(comp_fname) = upper('Daniel')
                AND upper(comp_lname) = upper('Kai')
        )
    AND entry_no = (
        SELECT
            entry_no
        FROM
                 competitor
            NATURAL JOIN entry
            NATURAL JOIN event
            NATURAL JOIN carnival
        WHERE
                upper(carn_name) = upper('RM Autumn Series Caulfield 2024')
            AND upper(comp_fname) = upper('Daniel')
            AND upper(comp_lname) = upper('Kai')
    );


UPDATE entry
SET
    team_id = NULL,
    char_id = (
        SELECT
            char_id
        FROM
            charity
        WHERE
            upper(char_name) = upper('Beyond Blue')
    )
WHERE
        event_id = (
            SELECT
                event_id
            FROM
                     competitor
                NATURAL JOIN entry
                NATURAL JOIN event
                NATURAL JOIN carnival
            WHERE
                    upper(carn_name) = upper('RM Autumn Series Caulfield 2024')
                AND upper(comp_fname) = upper('Annabelle')
                AND upper(comp_lname) = upper('Kai')
        )
    AND entry_no = (
        SELECT
            entry_no
        FROM
                 competitor
            NATURAL JOIN entry
            NATURAL JOIN event
            NATURAL JOIN carnival
        WHERE
                upper(carn_name) = upper('RM Autumn Series Caulfield 2024')
            AND upper(comp_fname) = upper('Annabelle')
            AND upper(comp_lname) = upper('Kai')
    );


DELETE FROM team
WHERE
        upper(team_name) = upper('Kai Speedstars')
    AND carn_date = (
        SELECT
            carn_date
        FROM
            carnival
        WHERE
            upper(carn_name) = upper('RM Autumn Series Caulfield 2024')
    );

COMMIT;

