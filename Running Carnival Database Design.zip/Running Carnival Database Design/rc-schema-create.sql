-- DROP table
DROP TABLE carnival CASCADE CONSTRAINTS;

DROP TABLE charity CASCADE CONSTRAINTS;

DROP TABLE competitor CASCADE CONSTRAINTS;

DROP TABLE emercontact CASCADE CONSTRAINTS;

DROP TABLE entry CASCADE CONSTRAINTS;

DROP TABLE event CASCADE CONSTRAINTS;

DROP TABLE eventtype CASCADE CONSTRAINTS;

DROP TABLE team CASCADE CONSTRAINTS;

-- CREATING table CARNIVAL
CREATE TABLE carnival (
    carn_date     DATE NOT NULL,
    carn_name     VARCHAR2(50) NOT NULL,
    carn_director VARCHAR2(50) NOT NULL,
    carn_location VARCHAR2(50) NOT NULL
);

COMMENT ON COLUMN carnival.carn_date IS
    'Date of carnival (unique identifier)';

COMMENT ON COLUMN carnival.carn_name IS
    'Carnival name';

COMMENT ON COLUMN carnival.carn_director IS
    'Carnival director''s name';

COMMENT ON COLUMN carnival.carn_location IS
    'Carnival''s location';

ALTER TABLE carnival ADD CONSTRAINT carnival_pk PRIMARY KEY ( carn_date );

ALTER TABLE carnival ADD CONSTRAINT carnival_uq UNIQUE ( carn_name );

-- CREATING table CHARITY
CREATE TABLE charity (
    char_id      NUMBER(3) NOT NULL,
    char_name    VARCHAR2(30) NOT NULL,
    char_contact VARCHAR2(50) NOT NULL,
    char_phone   CHAR(10) NOT NULL
);

COMMENT ON COLUMN charity.char_id IS
    'Charity unique identifier';

COMMENT ON COLUMN charity.char_name IS
    'Approved charity name';

COMMENT ON COLUMN charity.char_contact IS
    'Charity contact person name';

COMMENT ON COLUMN charity.char_phone IS
    'Charity phone number';

ALTER TABLE charity ADD CONSTRAINT charity_pk PRIMARY KEY ( char_id );

-- CREATING table EVENT
CREATE TABLE event (
    event_id        NUMBER(6) NOT NULL,
    carn_date       DATE NOT NULL,
    eventtype_code  CHAR(3) NOT NULL,
    event_starttime DATE NOT NULL
);

COMMENT ON COLUMN event.event_id IS
    'Event id (surrogate primary key)';

COMMENT ON COLUMN event.carn_date IS
    'Date of carnival (unique identifier)';

COMMENT ON COLUMN event.eventtype_code IS
    'Even type code, reflects the distance of the event, e.g 10K is for 10 kilometer ';

COMMENT ON COLUMN event.event_starttime IS
    'Event scheduled start time';

ALTER TABLE event ADD CONSTRAINT event_pk PRIMARY KEY ( event_id );

ALTER TABLE event ADD CONSTRAINT event_nk UNIQUE ( carn_date,
                                                   eventtype_code );

-- CREATING table EVENTTYPE
CREATE TABLE eventtype (
    eventtype_code CHAR(3) NOT NULL,
    eventtype_desc VARCHAR2(50) NOT NULL
);

COMMENT ON COLUMN eventtype.eventtype_code IS
    'Even type code, reflects the distance of the event, e.g 10K is for 10 kilometer ';

COMMENT ON COLUMN eventtype.eventtype_desc IS
    'Even type description';

ALTER TABLE eventtype ADD CONSTRAINT eventtype_pk PRIMARY KEY ( eventtype_code );

ALTER TABLE eventtype ADD CONSTRAINT eventtype_uq UNIQUE ( eventtype_desc );
                                                   
-- ADDING FK Constraints for table EVENT
ALTER TABLE event
    ADD CONSTRAINT carvinal_event FOREIGN KEY ( carn_date )
        REFERENCES carnival ( carn_date );

ALTER TABLE event
    ADD CONSTRAINT eventype_event_fk FOREIGN KEY ( eventtype_code )
        REFERENCES eventtype ( eventtype_code );
                                                   
-- COMPETITOR
CREATE TABLE competitor (
    comp_no              NUMBER(5) NOT NULL,
    comp_fname           VARCHAR2(30),
    comp_lname           VARCHAR2(30),
    comp_gender          CHAR(1) CHECK ( comp_gender IN ( 'M', 'F', 'U' ) ) NOT NULL,
    comp_dob             DATE NOT NULL,
    comp_email           VARCHAR2(50) NOT NULL,
    comp_unistatus       CHAR(1) CHECK ( comp_unistatus IN ( 'Y', 'N' ) ) NOT NULL,
    comp_phone           CHAR(10) NOT NULL,
    comp_ec_relationship CHAR(1) CHECK ( comp_ec_relationship IN ( 'P', 'G', 'T', 'F') ) NOT NULL,
    ec_phone             CHAR(10) NOT NULL,
    CONSTRAINT competitor_pk PRIMARY KEY ( comp_no )
);

COMMENT ON COLUMN competitor.comp_no IS
    'Competitor''s number (unique identifier)';

COMMENT ON COLUMN competitor.comp_fname IS
    'Competitor''s first name';   

COMMENT ON COLUMN competitor.comp_lname IS
    'Competitor''s last name';  
    
COMMENT ON COLUMN competitor.comp_gender  IS
    'Competitor''s gender';  
    
COMMENT ON COLUMN competitor.comp_dob IS
    'Competitor''s date of birth';  
    
COMMENT ON COLUMN competitor.comp_email  IS
    'Competitor''s email';  
    
COMMENT ON COLUMN competitor.comp_unistatus IS
    'Competitor''s university student/staff status'; 
    
COMMENT ON COLUMN competitor.comp_phone IS
    'Competitor''s phone number'; 

COMMENT ON COLUMN competitor.comp_ec_relationship IS
    'Emergency contact relationship to competitor';

COMMENT ON COLUMN competitor.ec_phone IS
    'Emergency contact''s phone number';

    
-- EMERCONTACT
CREATE TABLE emercontact (
    ec_phone CHAR(10) NOT NULL,
    ec_fname VARCHAR(30),
    ec_lname VARCHAR2(30),
    CONSTRAINT emercontact_pk PRIMARY KEY ( ec_phone )
);

COMMENT ON COLUMN emercontact.ec_phone IS
    'Emergency contact''s phone number (unique identifier)';

COMMENT ON COLUMN emercontact.ec_fname IS
    'Emergency contact''s first name';

COMMENT ON COLUMN emercontact.ec_lname IS
    'Emergency contact''s last name';


--ENTRY
CREATE TABLE entry (
    event_id         NUMBER(6) NOT NULL,
    entry_no         NUMBER(5) NOT NULL,
    entry_starttime  DATE,
    entry_finishtime DATE,
    comp_no          NUMBER(5) NOT NULL,
    team_id          NUMBER(3),
    char_id          NUMBER(3),
    CONSTRAINT entry_pk PRIMARY KEY ( event_id,
                                      entry_no )
);

COMMENT ON COLUMN entry.event_id IS
    'Event id (surrogate primary key)';
    
COMMENT ON COLUMN entry.entry_no IS
    'Entry number';
    
COMMENT ON COLUMN entry.entry_starttime IS
    'The entrant start time';

COMMENT ON COLUMN entry.entry_finishtime IS
    'The entrant finish time';

COMMENT ON COLUMN entry.comp_no IS
    'Competitor registration number (unique)';

COMMENT ON COLUMN entry.team_id IS
    'Team identifier (unique)';

COMMENT ON COLUMN entry.char_id IS
    'Charity unique identifier';

--TEAM
CREATE TABLE team (
    team_id         NUMBER(3) NOT NULL,
    team_name       VARCHAR(30) NOT NULL,
    carn_date       DATE NOT NULL,
    team_no_members NUMBER(2) NOT NULL,
    event_id        NUMBER(6) NOT NULL,
    entry_no        NUMBER(5) NOT NULL,
    char_id         NUMBER(3),
    CONSTRAINT team_pk PRIMARY KEY ( team_id )
);

COMMENT ON COLUMN team.team_id IS
    'Team identifier (unique)';

COMMENT ON COLUMN team.team_name IS
    'Team name';

COMMENT ON COLUMN team.carn_date IS
    'Date of carnival (unique identifier)';

COMMENT ON COLUMN team.team_no_members IS
    'Number of team members';
    
COMMENT ON COLUMN team.event_id IS
    'Event id (surrogate primary key)';

COMMENT ON COLUMN team.entry_no IS
    'Entry number';

COMMENT ON COLUMN team.char_id IS
    'Charity unique identifier';

-- Add all missing FK Constraints below here

ALTER TABLE competitor
    ADD CONSTRAINT emercontact_competitor FOREIGN KEY ( ec_phone )
        REFERENCES emercontact ( ec_phone );
            
ALTER TABLE team
    ADD CONSTRAINT carnival_team FOREIGN KEY ( carn_date )
        REFERENCES carnival ( carn_date );

ALTER TABLE team
    ADD CONSTRAINT carn_date_uq UNIQUE ( carn_date,team_name );

ALTER TABLE team
    ADD CONSTRAINT entry_team FOREIGN KEY ( entry_no,event_id )
        REFERENCES entry ( entry_no,event_id );


ALTER TABLE team
    ADD CONSTRAINT charity_team FOREIGN KEY ( char_id )
        REFERENCES charity ( char_id );

ALTER TABLE entry
    ADD CONSTRAINT event_entry FOREIGN KEY ( event_id )
        REFERENCES event ( event_id );

ALTER TABLE entry
    ADD CONSTRAINT competitor_entry FOREIGN KEY ( comp_no )
        REFERENCES competitor ( comp_no );

ALTER TABLE entry
    ADD CONSTRAINT team_entry FOREIGN KEY ( team_id )
        REFERENCES team ( team_id );
        
ALTER TABLE entry
    ADD CONSTRAINT charity_entry FOREIGN KEY ( char_id )
        REFERENCES charity ( char_id );

COMMIT;       
